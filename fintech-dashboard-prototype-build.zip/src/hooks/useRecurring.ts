import { useMemo } from 'react';
import { Transaction, RecurringPattern } from '../types';

// ─── Constants ─────────────────────────────────────────────────────────────────

const MIN_OCCURRENCES = 2; // need at least 2 hits to flag as recurring

// ─── Date helpers ──────────────────────────────────────────────────────────────

function addDays(date: string, days: number): string {
  const d = new Date(date + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function daysBetween(a: string, b: string): number {
  const da = new Date(a + 'T00:00:00');
  const db = new Date(b + 'T00:00:00');
  return Math.abs(Math.round((db.getTime() - da.getTime()) / 86_400_000));
}

function detectFrequency(avgDays: number): RecurringPattern['frequency'] {
  if (avgDays <= 10)  return 'weekly';
  if (avgDays <= 45)  return 'monthly';
  return 'annual';
}

function normalise(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '');
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useRecurring(transactions: Transaction[]): RecurringPattern[] {
  return useMemo(() => {
    // Group debits by normalised merchant name
    const groups = new Map<string, Transaction[]>();

    transactions
      .filter(tx => tx.type === 'debit')
      .forEach(tx => {
        const key = normalise(tx.merchant);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(tx);
      });

    const patterns: RecurringPattern[] = [];

    groups.forEach((txs, _key) => {
      if (txs.length < MIN_OCCURRENCES) return;

      // Sort chronologically
      const sorted = [...txs].sort((a, b) => a.date.localeCompare(b.date));

      // Calculate average days between occurrences
      const gaps: number[] = [];
      for (let i = 1; i < sorted.length; i++) {
        gaps.push(daysBetween(sorted[i - 1].date, sorted[i].date));
      }

      const avgGap = gaps.length > 0
        ? gaps.reduce((a, b) => a + b, 0) / gaps.length
        : 30;

      // Only flag as recurring if gap is reasonably consistent (CV < 0.5)
      const variance = gaps.length > 1
        ? gaps.reduce((s, g) => s + Math.pow(g - avgGap, 2), 0) / gaps.length
        : 0;
      const cv = avgGap > 0 ? Math.sqrt(variance) / avgGap : 1;
      if (cv > 0.6 && txs.length < 4) return; // too irregular to be "recurring"

      const freq      = detectFrequency(avgGap);
      const lastSeen  = sorted[sorted.length - 1].date;
      const nextGap   = freq === 'weekly' ? 7 : freq === 'monthly' ? 30 : 365;
      const nextExpected = addDays(lastSeen, nextGap);
      const avgAmount = sorted.reduce((a, tx) => a + tx.amount, 0) / sorted.length;
      const totalSpent = sorted.reduce((a, tx) => a + tx.amount, 0);

      patterns.push({
        merchant:     sorted[0].merchant, // use original casing
        category:     sorted[0].category,
        avgAmount:    Math.round(avgAmount * 100) / 100,
        frequency:    freq,
        lastSeen,
        nextExpected,
        occurrences:  sorted.length,
        totalSpent:   Math.round(totalSpent * 100) / 100,
      });
    });

    // Sort by total spent descending
    return patterns.sort((a, b) => b.totalSpent - a.totalSpent);
  }, [transactions]);
}
